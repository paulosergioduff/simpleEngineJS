function desenhaJogadorInicial()
	{
					window.document.getElementById('jogador').innerHTML = '<div style="position:fixed; bottom:'+jogadoInicioY+'px; left:'+jogadorInicioX+'px; width: '+larguraJogador+'px; height: '+alturaJogador+'px; border-style: solid; border-color: pink; "></div>';
			}

function desenhaNaTela($jogadorX, $jogadorY)
			  	{
			  		window.document.getElementById('jogador').innerHTML = '<div style="position:fixed; bottom:'+jogadorY+'px; left:'+jogadorX+'px; height:'+alturaJogador+'px; width:'+larguraJogador+'px; border-style: solid; border-color: red;"><div id="sprite"><img src="video/sprites/frente.png"></div></div></div>';
			  		colisao();
			  		}
function desenhaObjeto()
	{
		window.document.getElementById('objeto').innerHTML = '<div style="width: '+larguraObjeto+'px; height: '+alturaObjeto+'px; border-style: solid; border-color: green; position: fixed; bottom: '+objetoInicioY+'px; left: '+objetoInicioX+'px;"></div>';
	}



