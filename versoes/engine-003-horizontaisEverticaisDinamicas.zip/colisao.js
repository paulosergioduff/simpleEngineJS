function colisao($larguraObjeto, $larguraJogador, $inicialHjogador)
	{
		// ic = início de colisão
		// fc = fim de colisão
		// e ou d = direita e esquerda. Portanto ice seria início de colisão direita. e Por ai vai...
		var toleranciaColisao = 15;
		var fimColisao = toleranciaColisao * 2;
		var ice = inicialHjogador + $larguraJogador + inicialHjogador - toleranciaColisao ; // 235; // Início da colisão direita
		var fce = inicialHjogador + $larguraJogador + larguraObjeto + fimColisao;

		var icd = ice + larguraJogador + larguraObjeto + toleranciaColisao;
		var fcd = ice + larguraJogador + larguraObjeto + fimColisao;


		// Colisão para esquerda
		if (horizontalJogador > ice & verticalJogador > 250 & horizontalJogador < fce) {
			var esquerda = true;
		window.document.getElementById('colisaoEsquerda').innerHTML = 'Detectada :'+esquerda;
		horizontalJogador = horizontalJogador -6;
			}
			else{
						var esquerda = false;
						window.document.getElementById('colisaoEsquerda').innerHTML = 'Esquerda :'+esquerda;
				}

		// Colisão para direita
		if (horizontalJogador > icd & verticalJogador > 250 & horizontalJogador < fcd) {
			var direita = true;
		window.document.getElementById('colisaoEsquerda').innerHTML = 'Detectada :'+direita;
		horizontalJogador = horizontalJogador +6;
			}
			else{
						var esquerda = false;
						window.document.getElementById('colisaoDireita').innerHTML = 'Direia :'+esquerda;
				}

				window.document.getElementById('inicioColisaoE').innerHTML = "início colisão esquerda: "+ice;
				window.document.getElementById('fimColisaoE').innerHTML = "fim colisão esquerda: "+fce;
			window.document.getElementById('inicioColisaoD').innerHTML = "início colisão direita: "+icd;
			window.document.getElementById('fimColisaoD').innerHTML = "fim colisão direita: "+fcd;

			}	