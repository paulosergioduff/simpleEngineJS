function colisao()
	{
		// ic = início de colisão
		// fc = fim de colisão
		// e ou d = direita e esquerda. Portanto ice seria início de colisão direita. e Por ai vai...
		var toleranciaColisao = 15;
		var fimColisao = toleranciaColisao * 2;
		var ice = jogadorInicioX + larguraJogador + jogadorInicioX - toleranciaColisao ; // 235; // Início da colisão direita
		var fce = jogadorInicioX + larguraJogador + larguraObjeto + fimColisao;

		var icd = ice + larguraJogador + larguraObjeto + toleranciaColisao;
		var fcd = ice + larguraJogador + larguraObjeto + fimColisao;


		// Colisão para esquerda
		if (jogadorX > ice & jogadorY > 250 & jogadorX < fce) {
			var esquerda = true;
		window.document.getElementById('colisaoEsquerda').innerHTML = 'Detectada :'+esquerda;
		jogadorX = jogadorX -6;
			}
			else{
						var esquerda = false;
						window.document.getElementById('colisaoEsquerda').innerHTML = 'Esquerda :'+esquerda;
				}

		// Colisão para direita
		if (jogadorX > icd & jogadorY > 250 & jogadorX < fcd) {
			var direita = true;
		window.document.getElementById('colisaoEsquerda').innerHTML = 'Detectada :'+direita;
		jogadorX = jogadorX +6;
			}
			else{
						var esquerda = false;
						window.document.getElementById('colisaoDireita').innerHTML = 'Direia :'+esquerda;
				}

				window.document.getElementById('inicioColisaoE').innerHTML = "início colisão esquerda: "+ice;
				window.document.getElementById('fimColisaoE').innerHTML = "fim colisão esquerda: "+fce;
			window.document.getElementById('inicioColisaoD').innerHTML = "início colisão direita: "+icd;
			window.document.getElementById('fimColisaoD').innerHTML = "fim colisão direita: "+fcd;

			}	