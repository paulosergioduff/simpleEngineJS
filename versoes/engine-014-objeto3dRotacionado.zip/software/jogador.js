var jogadorInicioX = 50;
var jogadoInicioY = 50;
var jogadorX = jogadorInicioX;
var jogadorY = jogadoInicioY;
var larguraJogador  = 35;
var alturaJogador  = 58;