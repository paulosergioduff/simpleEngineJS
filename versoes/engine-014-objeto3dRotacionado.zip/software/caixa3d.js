var	larguraCaixa = 150;
	var alturaCaixa  = 150;
	var perspective = 600;
	var rotateY = 65.1;
	var rotateX = 5;


	