var objeto2InicioX = 250;
var objeto2InicioY = 300;
var objeto2X = objeto2InicioX;
var objeto2Y = objeto2InicioY;
var larguraObjeto2  = 150;
var alturaObjeto2  = 50;

