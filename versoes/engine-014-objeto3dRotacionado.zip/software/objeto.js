var objetoInicioX = 550;
var objetoInicioY = 200;
var objetoX = objetoInicioX;
var objetoY = objetoInicioY;
var larguraObjeto  = 150;
var alturaObjeto  = 50;

