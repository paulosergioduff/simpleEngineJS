var jogadorInicioX = 50;
var jogadoInicioY = 50;
var jogadorX = jogadorInicioX;
var jogadorY = jogadoInicioY;
var larguraJogador  = 60;
var alturaJogador  = 150;


var objetoInicioX = 400;
var objetoInicioY = 400;
var objetoX = objetoInicioX;
var objetoY = objetoInicioY;
var larguraObjeto  = 150;
var alturaObjeto  = 50;

function desenhaJogadorInicial()
	{
					window.document.getElementById('jogador').innerHTML = '<div style="position:fixed; bottom:'+jogadoInicioY+'px; left:'+jogadorInicioX+'px; width: '+larguraJogador+'px; height: '+alturaJogador+'px; border-style: solid; border-color: pink; "></div>';
			}

function desenhaNaTela($jogadorX, $jogadorY)
			  	{
			  		window.document.getElementById('jogador').innerHTML = '<div style="position:fixed; bottom:'+jogadorY+'px; left:'+jogadorX+'px; height:'+alturaJogador+'px; width:'+larguraJogador+'px; border-style: solid; border-color: red;"></div></div>';
			  		colisao();
			  		}
function desenhaObjeto()
	{
		window.document.getElementById('objeto').innerHTML = '<div style="width: '+larguraObjeto+'px; height: '+alturaObjeto+'px; border-style: solid; border-color: green; position: fixed; bottom: '+objetoInicioY+'px; left: '+objetoInicioY+'px;"></div>';
	}



