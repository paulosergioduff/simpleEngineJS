var objetoInicioX = 550;
var objetoInicioY = 100;
var objetoX = objetoInicioX;
var objetoY = objetoInicioY;
var larguraObjeto  = 150;
var alturaObjeto  = 50;