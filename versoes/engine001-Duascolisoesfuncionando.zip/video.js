var inicialHjogador = 50;
var inicialVjogador = 50;
var horizontalJogador = inicialHjogador;
var verticalJogador = inicialVjogador;
var larguraJogador  = 150;
var alturaJogador  = 150;


var inicialHobjeto = 400;
var inicialVobjeto = 400;
var larguraObjeto  = 150;
var alturaJogador  = 150;

function desenhaJogadorInicial()
	{
				window.document.getElementById('jogador').innerHTML = '<div style="position:fixed; bottom:'+inicialVjogador+'px; left:'+inicialHjogador+'px; width: '+larguraJogador+'px; height: '+alturaJogador+'px; border-style: solid; border-color: pink; "></div>';
			}

function desenhaNaTela($horizontalJogador, $verticalJogador)
			  	{
			  		window.document.getElementById('jogador').innerHTML = '<div style="position:fixed; bottom:'+verticalJogador+'px; left:'+horizontalJogador+'px;" class="jogadorEmMovimento"><div id="alvo"></div></div>';
			  		colisao();
			  		}
function desenhaObjeto()
	{
		window.document.getElementById('objeto').innerHTML = '<div style="width: 150px; height: 150px; border-style: solid; border-color: green; position: fixed; bottom: '+inicialVobjeto+'px; left: '+inicialVobjeto+'px;"></div>';
	}



