function colisao($larguraObjeto, $larguraJogador, $inicialHjogador)
	{
		var toleranciaColisao = 15;
		var ice = $larguraObjeto + $larguraJogador - toleranciaColisao; // Início da colisão direita



		// Colisão para esquerda
		if (horizontalJogador > 235 & verticalJogador > 250 & horizontalJogador < 410) {
			var esquerda = true;
		window.document.getElementById('colisaoEsquerda').innerHTML = 'Detectada :'+esquerda;
		horizontalJogador = horizontalJogador -6;
			}
			else{
						var esquerda = false;
						window.document.getElementById('colisaoEsquerda').innerHTML = 'Esquerda :'+esquerda;
				}

		// Colisão para direita
		if (horizontalJogador > 554 & verticalJogador > 250 & horizontalJogador < 560) {
			var direita = true;
		window.document.getElementById('colisaoEsquerda').innerHTML = 'Detectada :'+direita;
		horizontalJogador = horizontalJogador +6;
			}
			else{
						var esquerda = false;
						window.document.getElementById('colisaoDireita').innerHTML = 'Direia :'+esquerda;
				}

				window.document.getElementById('inicioColisaoE').innerHTML = "início colisão esquerda: "+ice;
	}