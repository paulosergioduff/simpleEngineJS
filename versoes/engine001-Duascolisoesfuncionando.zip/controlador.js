function cima()	
	{
		window.document.getElementById('cursorV').innerHTML = 'w '+verticalJogador;
			     	verticalJogador = verticalJogador+4;
			     	desenhaNaTela(horizontalJogador, verticalJogador);
	}
function baixo()
	{
		window.document.getElementById('cursorV').innerHTML = 's '+verticalJogador;
			     	verticalJogador = verticalJogador-4;
			     	desenhaNaTela(horizontalJogador, verticalJogador);

	}

function esquerda()
	{
		window.document.getElementById('cursorH').innerHTML = 'a '+horizontalJogador;
			     	horizontalJogador = horizontalJogador-4;
			     	desenhaNaTela(horizontalJogador, verticalJogador);
	}

function direita()
	{
		window.document.getElementById('cursorH').innerHTML = 'd'+horizontalJogador;
			    	horizontalJogador = horizontalJogador+4;
			    	desenhaNaTela(horizontalJogador, verticalJogador);

	}