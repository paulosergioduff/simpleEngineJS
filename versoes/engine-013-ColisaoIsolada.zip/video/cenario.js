var cenarioInicialX = 0; // RESERVADOR PARA CÁLCULOS FUTUROS
var cenarioInicialY = 0;
var cenarioX = cenarioInicialX;
var cenarioY = cenarioInicialY;

var cameraEsquerda = jogadorX - jogadorInicioX;